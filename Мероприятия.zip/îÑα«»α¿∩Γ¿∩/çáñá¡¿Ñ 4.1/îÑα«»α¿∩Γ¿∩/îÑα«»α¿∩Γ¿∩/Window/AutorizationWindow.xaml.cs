﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Мероприятия.Window
{
    /// <summary>
    /// Логика взаимодействия для AutorizationWindow.xaml
    /// </summary>
    public partial class AutorizationWindow 
    {
        public AutorizationWindow()
        {
            InitializeComponent();
        }
        public class CheckClick : TextBox//Используется для Captcha
        {
            public int error { get; set; }
        }
        int Attempts;
        DateTime now = DateTime.Now;//текущие дата и время  
        int idUser;
        System.Windows.Threading.DispatcherTimer 
            timer1 = new System.Windows.Threading.DispatcherTimer();
        public void UsersFalse()//Блок неверной капчи
        {
            if (Attempts == 1 || Attempts == 2)
            {
                MessageBoxResult result = MessageBox.Show("Неверно введёт логин или пароль." +
                    "\nПроверьте введённые вами данные!",
                    "Информация", MessageBoxButton.OK, MessageBoxImage.Information);
            }
            if (Attempts == 3)
            {
                Captha captha = new Captha();
                captha.ShowDialog();
            }
            if (Attempts >= 4)//если пользователь продолжает вводить неверно логин и пароль
            {//вход продолжает блокироваться на 10 секунд
                timer1.Tick += new EventHandler(timerTick2);
                timer1.Interval = new TimeSpan(0, 0, 1);
                timer1.Start();
                if (stop != 0)
                {
                    tbLogin.IsEnabled = false;
                    tbPassword.IsEnabled = false;
                    MessageBox.Show(String.Format("Вход заблокирован на {0:0} секунд", stop));
                }
            }
        }
        private void btEnter_Click(object sender, RoutedEventArgs e)
        {
            var forJury = App.events.Juries.FirstOrDefault
                (c=>c.Email == tbLogin.Text 
                & c.Password == tbPassword.Text);
            var forModerator = App.events.Moderators.FirstOrDefault
                (c => c.Email == tbLogin.Text
                & c.Password == tbPassword.Text);
            var forOrganizer = App.events.Organizers.FirstOrDefault
                (c => c.Email == tbLogin.Text
                & c.Password == tbPassword.Text);
            var forParticipants = App.events.Participants.FirstOrDefault
                (c => c.Email == tbLogin.Text
                & c.Password == tbPassword.Text);
            if (forJury != null  )
            {
                if(forJury.id_Role == 1)
                {
                    WindowJuryModerator windowJuryModerator
                      = new WindowJuryModerator();
                    windowJuryModerator.TextForUsers.Text = "Окно жюри";
                    windowJuryModerator.Show();
                    this.Close();
                }
                else
                {
                    Attempts++;
                    UsersFalse();
                }
            }
            else
            {
                if (forModerator != null)
                {
                    if(forModerator.id_Role == 2)
                    {
                        WindowJuryModerator windowJuryModerator
                          = new WindowJuryModerator();
                        windowJuryModerator.TextForUsers.Text = "Окно модератора";
                        windowJuryModerator.Show();
                        this.Close();
                        this.Close();
                    }
                    else
                    {
                        Attempts++;
                        UsersFalse();
                    }
                }
                else
                {
                    if (forOrganizer != null )
                    {
                        if(forOrganizer.id_Role == 3)
                        {
                            WindowOrganizer windowOrganizer
                               = new WindowOrganizer(forOrganizer);
                            windowOrganizer.Show();
                            this.Close();
                        } 
                    }
                    else
                    {
                        Attempts++;
                        UsersFalse();
                    }
                }
                
            }
            

        }
        int stop = 10;
        private void timerTick2(object sender, EventArgs e)//Блокировка входа и заполнения при последующих неверных входах
        {
            if (stop == 0)
            {
                tbLogin.IsEnabled = true;
                tbPassword.IsEnabled = true;
                MessageBoxResult result = MessageBox.Show("Время вышло!\nПовторите вход заново!",
                    "Информация", MessageBoxButton.OK, MessageBoxImage.Information);
                timer1.Stop();
                stop = 10;
            }
            else
            {
                stop--;
            }

        }
    }
}
