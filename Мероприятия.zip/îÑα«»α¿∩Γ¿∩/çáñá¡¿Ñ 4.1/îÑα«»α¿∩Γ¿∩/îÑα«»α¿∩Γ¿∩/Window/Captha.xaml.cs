﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Мероприятия.Window
{
    /// <summary>
    /// Логика взаимодействия для Captha.xaml
    /// </summary>
    public partial class Captha 
    {
        public Captha()
        {
            InitializeComponent();
        }
        int error = 0;
        AutorizationWindow workAutho = new AutorizationWindow();
        string pwd2;
        int not = 15;
        System.Windows.Threading.DispatcherTimer timer 
            = new System.Windows.Threading.DispatcherTimer();
        private void b2_Click(object sender, RoutedEventArgs e)
        {
            canvas.Children.Clear();
            String allowchar = " ";
            allowchar = "A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z";
            allowchar += "a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,y,z";
            allowchar += "1,2,3,4,5,6,7,8,9,0";
            char[] a = { ',' };
            String[] ar = allowchar.Split(a);
            String pwd = "";
            String pw = "";
            string temp = "";
            Random r = new Random();
            int k = r.Next(4);
            for (int i = 0; i < k; i++)
            {
                temp = ar[(r.Next(0, ar.Length))];
                pwd += temp;
            }
            rt1.Text = pwd;
            rt1.FontSize = r.Next(20, 60);
            for (int i = k; i < 6; i++)
            {
                temp = ar[(r.Next(0, ar.Length))];
                pw += temp;
            }
            rt2.Text = pw;
            rt2.FontSize = r.Next(20, 60);
            tb2.Foreground = new SolidColorBrush(Color.FromRgb((byte)r.
                Next(1, 255), (byte)r.Next(1, 255), (byte)r.Next(1, 255)));
            pwd2 = pwd + pw;
            for (int i = 0; i < 800; i++)
            {
                Ellipse el = new Ellipse();
                el.Width = 5;
                el.Height = 5;
                el.Margin = new Thickness(r.Next(1, 220), r.Next(1, 190), 0, 0);
                el.Fill = new SolidColorBrush(Color.FromRgb((byte)r
                    .Next(1, 255), (byte)r.Next(1, 255), (byte)r.Next(1, 255)));
                canvas.Children.Add(el);
            }
            int not = 15;
            System.Windows.Threading.DispatcherTimer timer 
                = new System.Windows.Threading.DispatcherTimer();
        }

        private void b1_Click(object sender, RoutedEventArgs e)
        {
            if (captcha.Text != pwd2)
            {
                error++;
                if (error == 3)
                {
                    workAutho.IsEnabled = false;
                    this.IsEnabled = false;
                    captcha.Clear();
                    MessageBox.Show("Слишком много попыток, подождите", "Уведомление", MessageBoxButton.OK, MessageBoxImage.Exclamation);
                    timer.Tick += new EventHandler(timerTick);
                    timer.Interval = new TimeSpan(0, 0, 1);
                    timer.Start();
                }
                else
                {
                    b2_Click(sender, e);
                    captcha.Clear();
                    MessageBox.Show("Не верно");
                }


            }
            else
            {
                MessageBox.Show("Верно");
                Close();
            }
        }
        private void timerTick(object sender, EventArgs e)
        {
            if (not == 0)
            {
                workAutho.IsEnabled = true;
                this.IsEnabled = true;
                MessageBox.Show("Можете вводить captcha");
                timer.Stop();
                error = 0;
                not = 15;
            }
            else
            {
                not--;
            }

        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            b2_Click(sender, e);
        }
    }
}
