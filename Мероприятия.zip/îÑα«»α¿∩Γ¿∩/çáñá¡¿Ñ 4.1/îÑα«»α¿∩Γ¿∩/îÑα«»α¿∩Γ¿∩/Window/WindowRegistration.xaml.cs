﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using Мероприятия.DB;

namespace Мероприятия.Window
{
    /// <summary>
    /// Логика взаимодействия для WindowRegistration.xaml
    /// </summary>
    public partial class WindowRegistration
    {
        public WindowRegistration()
        {
            InitializeComponent();
            cmEvent.ItemsSource = App.events.Events.Select(c => c.Event1).ToList();
            cmGender.ItemsSource = App.events.Genders.Select(c => c.Name).ToList();
            cmRole.ItemsSource = App.events.Roles.Select(c=>c.Name).ToList();
        }
        public static bool ValidateEmail(string InputEmail)
        {
            Regex regex = new Regex(@"^([\w\.\-]+)@([\w\-]+)((\.(\w){2,3})+)$");
            Match match = regex.Match(InputEmail);
            if (match.Success)
                return true;
            else
                return false;
        }


        private void cbVisiblePass_Click(object sender, RoutedEventArgs e)
        {
            if (cbVisiblePass.IsChecked == true)
            {
                tbPassword.Text = psPassword.Password;
                tbPasswordPov.Text = psPasswordPov.Password;

                psPassword.Visibility = Visibility.Collapsed;
                psPasswordPov.Visibility = Visibility.Collapsed;
                tbPassword.Visibility = Visibility.Visible;
                tbPasswordPov.Visibility = Visibility.Visible;
            }
            if (cbVisiblePass.IsChecked == false)
            {
                psPassword.Password = tbPassword.Text;
                psPasswordPov.Password = tbPasswordPov.Text;
                tbPassword.Text = psPassword.Password;
                tbPasswordPov.Text = psPasswordPov.Password;
                tbPassword.Visibility = Visibility.Collapsed;
                tbPasswordPov.Visibility = Visibility.Collapsed;
                psPassword.Visibility = Visibility.Visible;
                psPasswordPov.Visibility = Visibility.Visible;
            }
        }

        private void btEnter_Click(object sender, RoutedEventArgs e)
        {
            int IDGender = App.events.Genders.Where(x => x.Name == cmGender.Text).Select(x => x.idGender).FirstOrDefault();
            int IDRole = App.events.Roles.Where(x => x.Name == cmRole.Text).Select(x => x.idRole).FirstOrDefault();
            int IDDirection = App.events.Directions.Where(x => x.Direction1 == cmDirection.Text).Select(x => x.idDirection).FirstOrDefault();
            int IDEvent = App.events.Events.Where(x => x.Event1 == cmEvent.Text).Select(x => x.idEvent).FirstOrDefault();
            DB.EventEntities db = new EventEntities();
            string email = tbEmail.Text;
            if (ValidateEmail(email))
            {
                if (cbVisiblePass.IsChecked == false)
                {
                    string txtPassword = tbPassword.Text;
                    psPassword.Password = txtPassword;

                    if (tbPassword.LineCount >= 6)
                    {
                        if (cmRole.SelectedIndex == 1)//Модератор
                        {
                            DB.Moderator moderator = new Moderator()
                            {
                                FIO = tbFIO.Text,
                                id_Gender = IDRole,
                                Email = tbEmail.Text,
                                Birthday = DateTime.Now,
                                id_Country = 1,
                                id_Direction = IDDirection,
                                id_Event = IDEvent,
                                Password = tbPassword.Text,
                                Foto = "primer",
                                id_Role = IDRole,
                                Image = null
                            };
                            db.Moderators.Add(moderator);
                            db.SaveChanges();
                        }
                        else
                        {
                            if (cmRole.SelectedIndex == 2)//Организатор
                            {
                                DB.Organizer organizer = new Organizer()
                                {
                                    FIO = tbFIO.Text,
                                    Email = tbEmail.Text,
                                    Birthday = DateTime.Now,
                                    id_Country = 1,
                                    Password = tbPassword.Text,
                                    Foto = "primer",
                                    id_Gender = IDGender,
                                    id_Role = IDRole,
                                    Image = null
                                };
                                db.Organizers.Add(organizer);
                                db.SaveChanges();
                            }
                            else
                            {
                                if (cmRole.SelectedIndex == 0)//Жюри
                                {
                                    DB.Jury jury = new Jury()
                                    {
                                        FIO = tbFIO.Text,
                                        id_Gender = IDGender,
                                        Email = tbEmail.Text,
                                        Birthday = DateTime.Now,
                                        id_Country = 1,
                                        id_Direction = IDDirection,
                                        Password = tbPassword.Text,
                                        Foto = "primer",
                                        id_Role = IDRole,
                                        Image = null
                                    };
                                    db.Juries.Add(jury);
                                    db.SaveChanges();
                                    MessageBox.Show("Данные успешно добавлены!");
                                }
                                else
                                {
                                    if (cmRole.SelectedIndex == 3)//Участник
                                    {
                                        DB.Participant participant = new Participant()
                                        {
                                            FIO = tbFIO.Text,
                                            Email = tbEmail.Text,
                                            Birthday = DateTime.Now,
                                            id_Country = 1,
                                            Password = tbPassword.Text,
                                            Foto = "primer",
                                            id_Gender = IDGender,
                                            id_Role = IDRole,
                                            Image = null
                                        };
                                        db.Participants.Add(participant);
                                        db.SaveChanges();
                                    }
                                }
                            }
                        }
                    }
                }
                else
                {
                    MessageBox.Show("Пароль должен содержать не менее 6 символов!");
                }
            }
            else
            {
                MessageBox.Show("Почта имеет неверный формат!");
            }
        }
    }
}
